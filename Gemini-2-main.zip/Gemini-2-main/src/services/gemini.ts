import { GoogleGenAI, type GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  attachment?: {
    type: 'image';
    url: string;
  };
}

export interface ChatOptions {
  model?: string;
  systemInstruction?: string;
}

export async function generateImage(prompt: string, options: { model?: string; aspectRatio?: "1:1" | "3:4" | "4:3" | "9:16" | "16:9" } = {}) {
  const modelName = options.model || "gemini-2.5-flash-image";
  
  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        imageConfig: {
          aspectRatio: options.aspectRatio || "1:1",
        },
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data received");
  } catch (error) {
    console.error("Image Generation Error:", error);
    throw error;
  }
}

export async function* sendMessageStream(
  messages: Message[],
  options: ChatOptions = {}
) {
  const modelName = options.model || "gemini-3.1-flash-lite-preview";
  
  const contents = messages.map(msg => ({
    role: msg.role,
    parts: [{ text: msg.content }]
  }));

  try {
    const stream = await ai.models.generateContentStream({
      model: modelName,
      contents: contents,
      config: {
        systemInstruction: options.systemInstruction,
      }
    });

    for await (const chunk of stream) {
      const response = chunk as GenerateContentResponse;
      yield response.text;
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Bot, 
  User, 
  Plus, 
  History, 
  Settings2, 
  Trash2, 
  ChevronRight,
  Terminal,
  Sparkles,
  Command,
  Loader2,
  Code,
  Image as ImageIcon,
  Share2,
  ExternalLink,
  Copy,
  Check,
  Download
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cn } from './lib/utils';
import { sendMessageStream, generateImage, type Message } from './services/gemini';

declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

interface ChatHistory {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}

export default function App() {
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [history, setHistory] = useState<ChatHistory[]>([]);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [showMultimodalModal, setShowMultimodalModal] = useState(false);
  const [multimodalPrompt, setMultimodalPrompt] = useState('');
  const [codePrompt, setCodePrompt] = useState('');
  const [copied, setCopied] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState('You are Gemini 2.0, a highly advanced AI assistant developed to be helpful, safe, and efficient.');
  const [selectedModel, setSelectedModel] = useState('gemini-3.1-flash-lite-preview');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('gemini_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setHistory(parsed);
        if (parsed.length > 0) {
          setCurrentChatId(parsed[0].id);
        }
      } catch (e) {
        console.error('Failed to load history', e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('gemini_history', JSON.stringify(history));
  }, [history]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [history, isStreaming]);

  const getCurrentMessages = () => {
    const chat = history.find(h => h.id === currentChatId);
    return chat?.messages || [];
  };

  const startNewChat = () => {
    const id = Date.now().toString();
    const newChat: ChatHistory = {
      id,
      title: 'New Conversation',
      messages: [],
      createdAt: Date.now()
    };
    setHistory([newChat, ...history]);
    setCurrentChatId(id);
    setSidebarOpen(false); // Close on mobile if needed
  };

  const deleteChat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newHistory = history.filter(h => h.id !== id);
    setHistory(newHistory);
    if (currentChatId === id) {
      setCurrentChatId(newHistory.length > 0 ? newHistory[0].id : null);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isStreaming) return;

    let chatId = currentChatId;
    if (!chatId) {
      const id = Date.now().toString();
      const newChat: ChatHistory = {
        id,
        title: input.slice(0, 30) + '...',
        messages: [],
        createdAt: Date.now()
      };
      setHistory([newChat, ...history]);
      chatId = id;
      setCurrentChatId(id);
    }

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    // Update history with user message
    setHistory(prev => prev.map(chat => 
      chat.id === chatId 
        ? { 
            ...chat, 
            messages: [...chat.messages, userMessage],
            title: chat.messages.length === 0 ? input.slice(0, 40) + (input.length > 40 ? '...' : '') : chat.title
          } 
        : chat
    ));

    const currentInput = input;
    setInput('');
    setIsStreaming(true);

    try {
      const messagesForApi = [...getCurrentMessages(), userMessage];
      let fullResponse = '';

      // Initialize AI message
      setHistory(prev => prev.map(chat => 
        chat.id === chatId 
          ? { 
              ...chat, 
              messages: [...chat.messages, { role: 'model', content: '', timestamp: Date.now() }] 
            } 
          : chat
      ));

      const stream = sendMessageStream(messagesForApi, {
        model: selectedModel,
        systemInstruction: systemPrompt
      });

      for await (const chunk of stream) {
        if (chunk) {
          fullResponse += chunk;
          setHistory(prev => prev.map(chat => 
            chat.id === chatId 
              ? {
                  ...chat,
                  messages: [
                    ...chat.messages.slice(0, -1),
                    { role: 'model', content: fullResponse, timestamp: Date.now() }
                  ]
                }
              : chat
          ));
        }
      }
    } catch (error) {
      console.error(error);
      setHistory(prev => prev.map(chat => 
        chat.id === chatId 
          ? {
              ...chat,
              messages: [
                ...chat.messages.slice(0, -1),
                { role: 'model', content: "Sorry, I encountered an error. Please check your API key or try again later.", timestamp: Date.now() }
              ]
            }
          : chat
      ));
    } finally {
      setIsStreaming(false);
    }
  };

  const handleGenerateCode = async () => {
    if (!codePrompt.trim() || isStreaming) return;
    
    const prompt = `Generate high-quality, professional code for the following request. Provide ONLY the code in a single markdown code block if possible, followed by a brief explanation of how it works.
    
    Request: ${codePrompt}`;
    
    setShowCodeModal(false);
    setInput(prompt);
    // Trigger handleSend manually with the prompt
    // We need to wait for state update or use a ref, but simpler to just call the logic
    setTimeout(() => {
      handleSend();
    }, 100);
    setCodePrompt('');
  };

  const handleGenerateImage = async () => {
    if (!multimodalPrompt.trim() || isStreaming) return;
    
    const prompt = multimodalPrompt;
    
    setShowMultimodalModal(false);
    setIsStreaming(true);
    setMultimodalPrompt('');

    // Ensure we have a chat session
    let chatId = currentChatId;
    if (!chatId) {
      const id = Date.now().toString();
      const newChat: ChatHistory = {
        id,
        title: `Generate Image: ${prompt.slice(0, 20)}...`,
        messages: [],
        createdAt: Date.now()
      };
      setHistory([newChat, ...history]);
      chatId = id;
      setCurrentChatId(id);
    }

    const userMsg: Message = {
      role: 'user',
      content: `Please generate an image for: ${prompt}`,
      timestamp: Date.now()
    };

    setHistory(prev => prev.map(chat => 
      chat.id === chatId 
        ? { ...chat, messages: [...chat.messages, userMsg] } 
        : chat
    ));

    try {
      const resultUrl = await generateImage(prompt);

      const modelMsg: Message = {
        role: 'model',
        content: `I've generated this image for you:`,
        timestamp: Date.now(),
        attachment: {
          type: 'image',
          url: resultUrl
        }
      };

      setHistory(prev => prev.map(chat => 
        chat.id === chatId 
          ? { ...chat, messages: [...chat.messages, modelMsg] } 
          : chat
      ));
    } catch (error: any) {
      console.error(error);
      let errorMessage = `Sorry, I failed to generate the image.`;
      
      if (error?.message?.includes('PERMISSION_DENIED') || error?.status === 403) {
        errorMessage = `Access Denied: The current API key does not have permission to use the image generation model.`;
      }

      const errorMsg: Message = {
        role: 'model',
        content: errorMessage,
        timestamp: Date.now()
      };
      setHistory(prev => prev.map(chat => 
        chat.id === chatId 
          ? { ...chat, messages: [...chat.messages, errorMsg] } 
          : chat
      ));
    } finally {
      setIsStreaming(false);
    }
  };

  const handleShare = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'Gemini 2.0 Chat',
          text: 'Check out this awesome AI assistant!',
          url: url
        });
      } else {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch (e) {
      console.error('Share failed', e);
    }
  };

  const handleDownloadImage = async (imageUrl: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `gemini-image-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed', error);
    }
  };

  return (
    <div className="flex h-screen bg-[#f9f9f9] text-[#1a1a1a] overflow-hidden">
      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {sidebarOpen && (
          <motion.div 
            initial={{ x: -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            className="w-72 bg-white border-r border-[#e5e5e5] flex flex-col z-20"
          >
            <div className="p-4 border-bottom border-[#e5e5e5] space-y-2">
              <button 
                onClick={startNewChat}
                className="w-full flex items-center justify-center gap-2 bg-[#141414] text-white py-2.5 rounded-lg font-medium hover:bg-black transition-all shadow-sm active:scale-95"
              >
                <Plus size={18} />
                New Chat
              </button>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => setShowCodeModal(true)}
                  title="Generate Code"
                  className="flex items-center justify-center p-2.5 bg-white border border-[#e5e5e5] text-black rounded-lg hover:bg-gray-50 transition-all shadow-sm active:scale-95"
                >
                  <Code size={18} />
                </button>
                <button 
                  onClick={() => {
                    setShowMultimodalModal(true);
                  }}
                  title="Generate Image"
                  className="flex items-center justify-center p-2.5 bg-white border border-[#e5e5e5] text-black rounded-lg hover:bg-gray-50 transition-all shadow-sm active:scale-95"
                >
                  <ImageIcon size={18} />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-2 py-4 space-y-1">
              <div className="px-3 mb-2 flex items-center gap-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                <History size={14} />
                Recent Activity
              </div>
              {history.map((chat) => (
                <div 
                  key={chat.id}
                  onClick={() => setCurrentChatId(chat.id)}
                  className={cn(
                    "group relative flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all",
                    currentChatId === chat.id 
                      ? "bg-[#f0f0f0] text-black" 
                      : "text-gray-600 hover:bg-[#f5f5f5]"
                  )}
                >
                  <Bot size={16} className={currentChatId === chat.id ? "text-black" : "text-gray-400"} />
                  <span className="flex-1 truncate text-sm font-medium">
                    {chat.title}
                  </span>
                  <button 
                    onClick={(e) => deleteChat(chat.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 rounded transition-opacity"
                  >
                    <Trash2 size={14} className="text-gray-400 hover:text-red-500" />
                  </button>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-[#e5e5e5]">
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-[#f5f5f5] transition-all"
              >
                <Settings2 size={18} />
                <span className="text-sm font-medium">Settings</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative min-w-0">
        {/* Header */}
        <header className="h-16 border-b border-[#e5e5e5] bg-white flex items-center justify-between px-4 sm:px-6 z-10">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-[#f0f0f0] rounded-lg transition-colors text-gray-500"
            >
              {sidebarOpen ? <ChevronRight className="rotate-180" size={20} /> : <History size={20} />}
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
                <Sparkles size={18} className="text-white" />
              </div>
              <h1 className="font-bold text-lg tracking-tight">Gemini 2.0</h1>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={handleShare}
              className="flex items-center gap-2 px-3 py-1.5 border border-[#e5e5e5] rounded-lg text-sm font-medium hover:bg-gray-50 transition-all"
            >
              {copied ? <Check size={16} className="text-green-500" /> : <Share2 size={16} />}
              <span className="hidden sm:inline">{copied ? 'Copied' : 'Share'}</span>
            </button>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-[#f0f0f0] rounded-full">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-medium text-gray-600">{selectedModel}</span>
            </div>
          </div>
        </header>

        {/* Settings Overlay */}
        <AnimatePresence>
          {showSettings && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/80 backdrop-blur-sm z-30 flex items-center justify-center p-4"
              onClick={() => setShowSettings(false)}
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white border border-[#e5e5e5] shadow-2xl rounded-2xl w-full max-w-lg overflow-hidden"
                onClick={e => e.stopPropagation()}
              >
                <div className="px-6 py-4 border-b border-[#e5e5e5] flex justify-between items-center">
                  <h3 className="font-bold text-lg">System Preferences</h3>
                  <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-black">
                    <Trash2 size={20} />
                  </button>
                </div>
                <div className="p-6 space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <ExternalLink size={16} />
                      App URL
                    </label>
                    <div className="flex gap-2">
                      <input 
                        readOnly
                        value={window.location.href}
                        className="flex-1 p-2 bg-[#f9f9f9] border border-[#e5e5e5] rounded-lg text-xs outline-none"
                      />
                      <button 
                        onClick={() => {
                          navigator.clipboard.writeText(window.location.href);
                          setCopied(true);
                          setTimeout(() => setCopied(false), 2000);
                        }}
                        className="p-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-all"
                      >
                        {copied ? <Check size={14} /> : <Copy size={14} />}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <Terminal size={16} />
                      System Instruction
                    </label>
                    <textarea 
                      value={systemPrompt}
                      onChange={(e) => setSystemPrompt(e.target.value)}
                      className="w-full h-32 p-3 bg-[#f9f9f9] border border-[#e5e5e5] rounded-xl text-sm focus:ring-2 focus:ring-black outline-none transition-all resize-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <Command size={16} />
                      Model Selection
                    </label>
                    <select 
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      className="w-full p-3 bg-[#f9f9f9] border border-[#e5e5e5] rounded-xl text-sm focus:ring-2 focus:ring-black outline-none transition-all appearance-none cursor-pointer"
                    >
                      <option value="gemini-3-flash-preview">Gemini 3 Flash (Fastest)</option>
                      <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Complex Reasoning)</option>
                      <option value="gemini-3.1-flash-lite-preview">Gemini 3.1 Flash Lite (Efficient)</option>
                    </select>
                  </div>
                </div>
                <div className="px-6 py-4 bg-[#f9f9f9] border-t border-[#e5e5e5] flex justify-end">
                  <button 
                    onClick={() => setShowSettings(false)}
                    className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-all"
                  >
                    Save Changes
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Code Generator Modal */}
        <AnimatePresence>
          {showCodeModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/80 backdrop-blur-sm z-30 flex items-center justify-center p-4"
              onClick={() => setShowCodeModal(false)}
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white border border-[#e5e5e5] shadow-2xl rounded-2xl w-full max-w-lg overflow-hidden"
                onClick={e => e.stopPropagation()}
              >
                <div className="px-6 py-4 border-b border-[#e5e5e5] flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Code className="text-black" size={20} />
                    <h3 className="font-bold text-lg">Generate Code</h3>
                  </div>
                  <button onClick={() => setShowCodeModal(false)} className="text-gray-400 hover:text-black">
                    <Trash2 size={20} className="rotate-45" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <p className="text-sm text-gray-500">Describe the code or feature you want to generate. Gemini 2.0 will provide a professional implementation.</p>
                  <textarea 
                    autoFocus
                    value={codePrompt}
                    onChange={(e) => setCodePrompt(e.target.value)}
                    placeholder="e.g., A React hook for debouncing search input..."
                    className="w-full h-40 p-4 bg-[#f9f9f9] border border-[#e5e5e5] rounded-xl text-sm focus:ring-2 focus:ring-black outline-none transition-all resize-none shadow-inner"
                  />
                </div>
                <div className="px-6 py-4 bg-[#f9f9f9] border-t border-[#e5e5e5] flex justify-end gap-3">
                  <button 
                    onClick={() => setShowCodeModal(false)}
                    className="px-6 py-2 rounded-lg font-medium text-gray-600 hover:bg-gray-200 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleGenerateCode}
                    disabled={!codePrompt.trim()}
                    className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 disabled:bg-gray-300 disabled:cursor-not-allowed transition-all shadow-md active:scale-95"
                  >
                    Generate
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Multimodal Generator Modal */}
        <AnimatePresence>
          {showMultimodalModal && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/80 backdrop-blur-sm z-30 flex items-center justify-center p-4"
              onClick={() => setShowMultimodalModal(false)}
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white border border-[#e5e5e5] shadow-2xl rounded-2xl w-full max-w-lg overflow-hidden"
                onClick={e => e.stopPropagation()}
              >
                <div className="px-6 py-4 border-b border-[#e5e5e5] flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="text-black" size={20} />
                    <h3 className="font-bold text-lg">Generate Image</h3>
                  </div>
                  <button onClick={() => setShowMultimodalModal(false)} className="text-gray-400 hover:text-black">
                    <Trash2 size={20} className="rotate-45" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <p className="text-sm text-gray-500">Describe the image you want to create. Gemini 2.0 will transform your words into reality.</p>
                  <textarea 
                    autoFocus
                    value={multimodalPrompt}
                    onChange={(e) => setMultimodalPrompt(e.target.value)}
                    placeholder="e.g., A futuristic cityscape with flying cars at sunset, cinematic lighting"
                    className="w-full h-40 p-4 bg-[#f9f9f9] border border-[#e5e5e5] rounded-xl text-sm focus:ring-2 focus:ring-black outline-none transition-all resize-none shadow-inner"
                  />
                </div>
                <div className="px-6 py-4 bg-[#f9f9f9] border-t border-[#e5e5e5] flex justify-end gap-3">
                  <button 
                    onClick={() => setShowMultimodalModal(false)}
                    className="px-6 py-2 rounded-lg font-medium text-gray-600 hover:bg-gray-200 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleGenerateImage}
                    disabled={!multimodalPrompt.trim()}
                    className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 disabled:bg-gray-300 disabled:cursor-not-allowed transition-all shadow-md active:scale-95"
                  >
                    Generate Image
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chat Area */}
        <div 
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto px-4 py-8 space-y-8 contents-container"
        >
          {getCurrentMessages().length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-xl mx-auto space-y-6">
              <motion.div 
                animate={{ 
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ duration: 4, repeat: Infinity }}
                className="w-20 h-20 bg-black rounded-3xl flex items-center justify-center shadow-2xl"
              >
                <Sparkles size={40} className="text-white" />
              </motion.div>
              <div className="space-y-2">
                <h2 className="text-3xl font-extrabold tracking-tight">How can I help you today?</h2>
                <p className="text-gray-500">I'm Gemini 2.0, your advanced neural companion. Ask me anything from code to creative writing.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                {[
                  "Write a React component for a task list",
                  "Explain quantum entanglement like I'm 5",
                  "Create a 7-day workout plan for beginners",
                  "Draft a professional email for a job application"
                ].map((hint, i) => (
                  <button 
                    key={i}
                    onClick={() => setInput(hint)}
                    className="p-4 bg-white border border-[#e5e5e5] rounded-xl text-left text-sm font-medium hover:border-black hover:shadow-md transition-all active:scale-[0.98]"
                  >
                    {hint}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto w-full space-y-8">
              {getCurrentMessages().map((msg, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={i} 
                  className={cn(
                    "flex gap-4 sm:gap-6",
                    msg.role === 'user' ? "flex-row-reverse" : ""
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm",
                    msg.role === 'user' ? "bg-white border border-[#e5e5e5]" : "bg-black"
                  )}>
                    {msg.role === 'user' ? <User size={20} className="text-gray-600" /> : <Bot size={20} className="text-white" />}
                  </div>
                  <div className={cn(
                    "flex-1 px-5 py-4 rounded-2xl md:max-w-[85%] overflow-hidden",
                    msg.role === 'user' 
                      ? "bg-[#141414] text-white rounded-tr-none" 
                      : "bg-white border border-[#e5e5e5] rounded-tl-none shadow-sm"
                  )}>
                    <div className="markdown-body">
                      <ReactMarkdown>
                        {msg.content}
                      </ReactMarkdown>
                      {msg.attachment && (
                        <div className="mt-4 group relative">
                            <img 
                              src={msg.attachment.url} 
                              alt="Generated content" 
                              className="rounded-lg w-full shadow-lg border border-gray-100"
                              referrerPolicy="no-referrer"
                            />
                            <button 
                              onClick={() => handleDownloadImage(msg.attachment!.url)}
                              className="absolute top-2 right-2 p-2 bg-black/50 hover:bg-black text-white rounded-full backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 shadow-lg"
                              title="Download Image"
                            >
                              <Download size={18} />
                            </button>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
              {isStreaming && (
                <div className="flex gap-4 sm:gap-6">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-black flex items-center justify-center flex-shrink-0 animate-pulse">
                    <Bot size={20} className="text-white" />
                  </div>
                  <div className="flex items-center gap-2 text-gray-400">
                    <Loader2 size={18} className="animate-spin" />
                    <span className="text-sm font-medium animate-pulse">Thinking...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} className="h-20" />
            </div>
          )}
        </div>

        {/* Input Dock */}
        <div className="p-4 sm:p-6 bg-gradient-to-t from-[#f9f9f9] to-transparent">
          <div className="max-w-4xl mx-auto w-full relative">
            <div className="relative flex items-center rounded-2xl bg-white border border-[#e5e5e5] shadow-xl hover:border-black transition-all group overflow-hidden">
              <textarea 
                rows={1}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Message Gemini 2.0..."
                className="w-full py-4 pl-5 pr-14 bg-transparent outline-none resize-none font-medium text-base max-h-48 scrollbar-hide"
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isStreaming}
                className={cn(
                  "absolute right-3 p-2 rounded-xl transition-all active:scale-90",
                  input.trim() && !isStreaming 
                    ? "bg-black text-white hover:bg-gray-800" 
                    : "bg-gray-100 text-gray-400 cursor-not-allowed"
                )}
              >
                {isStreaming ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
              </button>
            </div>
            <div className="mt-2 text-center">
              <p className="text-[10px] text-gray-400 font-medium tracking-wide flex items-center justify-center gap-1">
                <Command size={10} />
                Shift + Enter for new line • Gemini 2.0 may display inaccurate info
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

